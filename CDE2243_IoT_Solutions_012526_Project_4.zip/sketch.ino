/*************************************************
 * SMART ENVIRONMENT IoT PROJECT
 * ESP32 + DHT22 + MQ-2 + OLED + MQTT (ThingsBoard)
 *************************************************/

#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHT.h"

/* ================= WIFI CONFIG ================= */
const char* ssid = "Wokwi-GUEST";
const char* password = "";

/* ================= MQTT CONFIG ================= */
const char* mqttServer = "mqtt.thingsboard.cloud";
const int mqttPort = 1883;
const char* accessToken = "MDgtlAfyN3oCUQTZVHha";

/* ================= OLED CONFIG ================= */
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

/* ================= SENSOR CONFIG =============== */
#define DHTPIN 15
#define DHTTYPE DHT22
#define MQ2_PIN 34

/* ================= ANALYTICS CONFIG ============ */
#define GAS_THRESHOLD 1800
#define LED_PIN 25

DHT dht(DHTPIN, DHTTYPE);

/* ================= MQTT OBJECT ================= */
WiFiClient espClient;
PubSubClient client(espClient);

/* ================= WIFI CONNECT ================ */
void connectWiFi() {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

/* ================= MQTT CONNECT ================ */
void connectMQTT() {
  client.setServer(mqttServer, mqttPort);
  while (!client.connected()) {
    client.connect("ESP32Client", accessToken, NULL);
    delay(500);
  }
}

/* ================= SEND DATA =================== */
void sendToCloud(float t, float h, int gas, bool unsafe) {
  String payload = "{";
  payload += "\"temperature\":" + String(t) + ",";
  payload += "\"humidity\":" + String(h) + ",";
  payload += "\"gas\":" + String(gas) + ",";
  payload += "\"status\":\"" + String(unsafe ? "UNSAFE" : "SAFE") + "\"";
  payload += "}";

  client.publish("v1/devices/me/telemetry", payload.c_str());
}

/* ================= SETUP ======================= */
void setup() {
  pinMode(LED_PIN, OUTPUT);

  Wire.begin(21, 22);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Smart Environment");
  display.println("Starting...");
  display.display();

  dht.begin();

  connectWiFi();
  connectMQTT();

  delay(2000);
}

/* ================= LOOP ======================== */
void loop() {
  client.loop();

  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  int gasValue = analogRead(MQ2_PIN);

  bool unsafe = gasValue > GAS_THRESHOLD;

  // Autonomous action
  digitalWrite(LED_PIN, unsafe ? HIGH : LOW);

  // OLED Display
  display.clearDisplay();
  display.setCursor(0, 0);

  display.println("Sensor Readings");
  display.print("Temp: ");
  display.print(temperature);
  display.println(" C");

  display.print("Humidity: ");
  display.print(humidity);
  display.println(" %");

  display.print("Gas: ");
  display.println(gasValue);

  display.println("----------------");

  if (unsafe) {
    display.println("STATUS: UNSAFE!");
  } else {
    display.println("STATUS: SAFE");
  }

  display.display();

  // Send data to ThingsBoard
  sendToCloud(temperature, humidity, gasValue, unsafe);

  delay(3000);
}
